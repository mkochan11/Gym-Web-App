﻿
namespace Infrastructure.Helpers
{
    public class SeedUsersIds
    {
        public string AdminId { get; set; }
        public string OwnerId { get; set; }
        public string ManagerId { get; set; }
        public string ReceptionistId { get; set; }
        public string GroupTrainerId { get; set; }
        public string PersonalTrainerId { get; set; }
    }
}
