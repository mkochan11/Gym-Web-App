using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Web.Interfaces;
using Web.ViewModels.Calendar.Trainer.Trainings.Group;

namespace Web.Pages.Trener.Grupowy.HarmonogramZajec
{
    public class _groupTrainingModel : PageModel
    {
        public void OnGet()
        {
            
        }
    }
}
