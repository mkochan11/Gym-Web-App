using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Trener.Personalny.PlanyTreningowe
{
    public class _trainingPlanModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
