using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Trener.Personalny.PlanyTreningowe
{
    public class _editExerciseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
