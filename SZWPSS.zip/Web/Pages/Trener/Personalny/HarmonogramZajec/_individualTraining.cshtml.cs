using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Trener.HarmonogramZajec
{
    public class _individualTrainingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
