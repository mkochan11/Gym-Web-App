using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Menadzer.Pracownicy
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
