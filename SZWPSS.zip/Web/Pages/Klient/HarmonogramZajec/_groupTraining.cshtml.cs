using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Klient.HarmonogramZajec
{
    public class _groupTrainingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
