using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Klient.PlanyTreningowe
{
    public class _exerciseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
