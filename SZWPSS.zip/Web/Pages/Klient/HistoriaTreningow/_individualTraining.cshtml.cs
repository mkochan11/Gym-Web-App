using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Web.Pages.Klient.HistoriaTrening�w
{
    public class _individualTrainingModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
