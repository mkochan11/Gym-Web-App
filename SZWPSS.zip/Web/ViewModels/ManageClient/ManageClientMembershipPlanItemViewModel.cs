﻿namespace Web.ViewModels.ManageClient
{
    public class ManageClientMembershipPlanItemViewModel
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public decimal Price { get; set; }
        public string DurationTime { get; set; }
    }
}
