﻿namespace Web.ViewModels.Calendar.Client.TrainingsHistory
{
    public class ClientTrainingsHistoryIndexViewModel
    {
        public List<ClientTrainingsHistoryDayItemViewModel> DaysInMonth { get; set; } = new List<ClientTrainingsHistoryDayItemViewModel>();
    }
}
