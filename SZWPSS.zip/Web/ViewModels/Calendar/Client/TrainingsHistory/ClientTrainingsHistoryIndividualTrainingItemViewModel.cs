﻿namespace Web.ViewModels.Calendar.Client.TrainingsHistory
{
    public class ClientTrainingsHistoryIndividualTrainingItemViewModel : ClientTrainingsHistoryTrainingItemViewModel
    {
    }
}
