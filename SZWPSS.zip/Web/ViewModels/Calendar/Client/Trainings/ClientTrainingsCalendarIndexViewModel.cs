﻿namespace Web.ViewModels.Calendar.Client.Trainings
{
    public class ClientTrainingsCalendarIndexViewModel
    {
        public List<ClientTrainingsCalendarIndexDayItemViewModel> DaysInMonth { get; set; } = new List<ClientTrainingsCalendarIndexDayItemViewModel>();
    }
}
