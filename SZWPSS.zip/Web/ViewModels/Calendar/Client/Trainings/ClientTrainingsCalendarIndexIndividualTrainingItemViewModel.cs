﻿namespace Web.ViewModels.Calendar.Client.Trainings
{
    public class ClientTrainingsCalendarIndexIndividualTrainingItemViewModel : ClientTrainingsCalendarIndexTrainingItemViewModel
    {
        public bool IsReserved { get; set; }
    }
}
