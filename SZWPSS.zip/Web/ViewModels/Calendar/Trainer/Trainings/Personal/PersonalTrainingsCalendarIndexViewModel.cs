﻿namespace Web.ViewModels.Calendar.Trainer.Trainings.Personal
{
    public class PersonalTrainingsCalendarIndexViewModel
    {
        public List<PersonalTrainingsCalendarIndexDayItemViewModel> DaysInMonth { get; set; } = new List<PersonalTrainingsCalendarIndexDayItemViewModel>();
    }
}
