﻿namespace Web.ViewModels.WorkSchedule.Receptionist
{
    public class ReceptionistWorkScheduleShiftItemViewModel
    {
        public DateTime Date { get; set; }
        public TimeSpan Duration { get; set; }
    }
}
