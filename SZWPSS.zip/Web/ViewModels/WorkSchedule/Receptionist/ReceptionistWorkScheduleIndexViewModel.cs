﻿namespace Web.ViewModels.WorkSchedule.Receptionist
{
    public class ReceptionistWorkScheduleIndexViewModel
    {
        public List<ReceptionistWorkScheduleDayItemViewModel> DaysInMonth { get; set; } = new List<ReceptionistWorkScheduleDayItemViewModel>();
    }

}
