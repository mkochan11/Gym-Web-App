﻿namespace Web.ViewModels.WorkSchedule.Manager
{
    public class ManagerWorkScheduleReceptionistItemViewModelService
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
