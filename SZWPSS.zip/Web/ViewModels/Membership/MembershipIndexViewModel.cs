namespace Web.ViewModels.Membership
{
    public class MembershipIndexViewModel
    {
        public MembershipIndexItemViewModel MembershipIndexItem = new MembershipIndexItemViewModel();
        public bool IsFound;
    }
}