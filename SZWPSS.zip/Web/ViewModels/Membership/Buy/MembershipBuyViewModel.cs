﻿namespace Web.ViewModels.Membership.Buy
{
    public class MembershipBuyViewModel
    {
        public List<MembershipBuyPlanItemViewModel> Plans { get; set; }
        public bool IsFound {  get; set; }
    }
}
