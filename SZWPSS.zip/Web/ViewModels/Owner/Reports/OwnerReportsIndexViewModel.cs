﻿namespace Web.ViewModels.Owner.Reports
{
    public class OwnerReportsIndexViewModel
    {
        public List<OwnerReportsIndexItemViewModel> Reports { get; set; } = new List<OwnerReportsIndexItemViewModel>();
    }
}
