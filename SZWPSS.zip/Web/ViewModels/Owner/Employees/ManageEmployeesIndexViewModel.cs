﻿namespace Web.ViewModels.Owner.Employees
{
    public class ManageEmployeesIndexViewModel
    {
        public List<ManageEmployeesIndexItemViewModel> Employees { get; set; } = new List<ManageEmployeesIndexItemViewModel>();
    }
}
