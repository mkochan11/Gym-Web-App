﻿namespace Web.ViewModels.Admin.ManageUsers
{
    public class ManageUsersIndexViewModel
    {
        public List<ManageUsersIndexItemViewModel> Users { get; set; } = new List<ManageUsersIndexItemViewModel>();
    }
}
