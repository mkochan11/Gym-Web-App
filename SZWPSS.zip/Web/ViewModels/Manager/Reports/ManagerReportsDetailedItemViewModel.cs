﻿namespace Web.ViewModels.Manager.Reports
{
    public class ManagerReportsDetailedItemViewModel
    {
        public decimal HoursWorked { get; set; }
        public decimal MoneyEarned { get; set; }
    }
}
