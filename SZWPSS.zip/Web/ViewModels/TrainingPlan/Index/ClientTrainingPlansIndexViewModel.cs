﻿namespace Web.ViewModels.TrainingPlan.Index
{
    public class ClientTrainingPlansIndexViewModel
    {
        public List<ClientTrainingPlansIndexItemViewModel> TrainingPlans { get; set; } = new List<ClientTrainingPlansIndexItemViewModel>();
    }
}
