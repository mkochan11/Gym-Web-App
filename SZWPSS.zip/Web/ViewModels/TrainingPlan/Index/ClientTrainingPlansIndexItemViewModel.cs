﻿namespace Web.ViewModels.TrainingPlan.Index
{
    public class ClientTrainingPlansIndexItemViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string TrainerName { get; set; }
        public string TrainerSurname { get; set; }
    }
}
