﻿namespace Web.ViewModels.TrainingPlan.Index
{
    public class TrainingPlansIndexViewModel
    {
        public List<TrainingPlansIndexItemViewModel> TrainingPlans { get; set; } = new List<TrainingPlansIndexItemViewModel>();
    }
}
