﻿namespace Web.ViewModels.TrainingPlan.Add
{
    public class AddTrainingPlanIndexViewModel
    {
        public List<AddTrainingPlanClientItemViewModel> ClientItems { get; set; } = new List<AddTrainingPlanClientItemViewModel>();
    }
}
