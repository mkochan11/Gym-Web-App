﻿namespace Web.ViewModels.TrainingPlan.ClientDetails
{
    public class ClientTrainingPlanDetailsItemViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string TrainerName { get; set; }
        public string TrainerSurname { get; set; }
    }
}
