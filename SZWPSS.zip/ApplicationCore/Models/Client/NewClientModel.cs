﻿
namespace ApplicationCore.Models.Client
{
    public class NewClientModel
    {
        public required string AccountId { get; set; }
        public required string Name { get; set; }
        public required string Surname { get; set; }
    }
}
