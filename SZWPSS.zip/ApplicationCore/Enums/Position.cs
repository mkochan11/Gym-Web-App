﻿namespace ApplicationCore.Enums
{
    public enum Position
    {
        Admin,
        Owner,
        Manager,
        PersonalTrainer,
        GroupTrainer,
        Receptionist
    }
}
