﻿namespace ApplicationCore.Enums
{
    public enum PaymentStatus
    {
        Pending,
        Success,
        Failure
    }
}
