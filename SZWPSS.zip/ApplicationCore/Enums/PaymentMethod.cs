﻿namespace ApplicationCore.Enums
{
    public enum PaymentMethod
    {
        Karta,
        Przelew,
        BLIK,
        Gotówka
    }
}
