﻿using ApplicationCore.Entities.Abstract;

namespace ApplicationCore.Entities
{
    public class GroupTrainer : Trainer<GroupTraining>
    {
    }
}
