﻿using ApplicationCore.Entities.Abstract;

namespace ApplicationCore.Entities
{
    public class Manager : Employee
    {
    }
}
