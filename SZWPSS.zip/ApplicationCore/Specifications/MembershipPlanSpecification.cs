using ApplicationCore.Entities;
using Ardalis.Specification;

namespace ApplicationCore.Specifications
{
    public class MembershipPlanSpecification : SingleResultSpecification<MembershipPlan>
    {
    }
}